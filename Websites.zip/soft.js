function contactUs() {
    alert("Thank you for your interest! Please fill out the contact form below.");
  }
  document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Your message has been sent. We will contact you shortly!');
    document.getElementById('contactForm').reset();
  });